<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Espaço Esporte</title>
</head>
<body>
<div class="box">
        <a href="login.php">login</a>
        <a href="cadastro.php">Cadastro</a>
    </div>
</body>
</html>